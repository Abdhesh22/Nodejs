//file system module synchronous
const fs = require('fs');

// fs.writeFileSync("read.txt","hello from backend");
// fs.writeFileSync("read.txt","Again hello from backend");
// fs.appendFileSync("read.txt","\nanother hello from backend using append func");

// const buffer_code = fs.readFileSync("read.txt");
// let convert buffer into string data
// const original = buffer_code.toString();
// console.log(buffer_code);
// console.log(original);

// lets rename the filename
fs.renameSync("read.txt","write.txt")