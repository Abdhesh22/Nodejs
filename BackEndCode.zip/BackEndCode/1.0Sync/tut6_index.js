//challenge time
//crud operation -> create read update delete.
// const fs = require('fs');
// fs.mkdirSync("tut6");
// fs.writeFileSync('tut6/bio.txt',"my name is abdhesh kumar");
// fs.appendFileSync('tut6/bio.txt',"\n i am web developer");
// const data = fs.readFileSync('tut6/bio.txt',"utf8");
// fs.renameSync("tut6/hii.txt","tut6/bye.txt");
// fs.unlinkSync("tut6/bye.txt");
// fs.rmdirSync("tut6");
// console.log(data);