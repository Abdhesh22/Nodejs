// const fs = require('fs');

// fs.mkdir("Async",(err)=>{
//     console.log("Making Async folder");
// });
// 

// fs.appendFile("Async/async.txt","\n another hello from tut9_index.js",(err)=>{
//     console.log("just adding one more data");
// })

// fs.readFile("Async/async.txt","utf-8",(err,data)=>{
//     console.log(data);
// })

// fs.rename("Async/async.txt","newAsync.txt",(err)=>{
//     console.log("Renaming file ......");
// })

// fs.unlink("newAsync.txt",(err)=>{
//     console.log("deleting file");
// })

// fs.unlink("Async/async.txt",(Er)=>{
//     console.log("deleting file");
// })

// fs.rmdir("Async",(err)=>{
//     console.log("removing Folder");
// })