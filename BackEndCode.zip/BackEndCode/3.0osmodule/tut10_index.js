//operating system module
const os = require("os");

console.log(os.arch());
console.log(os.hostname());
console.log(os.platform());
console.log(os.tmpdir());
console.log(os.type());

console.log(os.freemem()); //give value in bytes

console.log(`in gb: ${os.freemem/1024/1024/1024}`);

const totalmemory = os.totalmem();

console.log(`in gb ${totalmemory/1024/1024/1024}`);