const path = require('path');

console.log(path.dirname('A:/BackEndCode/4.0Path_module/tut11_index.js'));
console.log(path.extname('A:/BackEndCode/4.0Path_module/tut11_index.js'));
console.log(path.basename('A:/BackEndCode/4.0Path_module/tut11_index.js'));

console.log(path.parse('A:/BackEndCode/4.0Path_module/tut11_index.js'));

const mypath = path.parse("A:/BackEndCode/4.0Path_module/tut11_index.js");
console.log(mypath.name);
console.log(mypath.root);
