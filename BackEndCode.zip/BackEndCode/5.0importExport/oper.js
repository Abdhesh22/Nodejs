const add = (a,b)=>{
    return a+b;
};

const subs=(a,b)=>{
    return a-b;
}

const name = "Abdhesh";

module.exports = {add,subs,name};

// module.exports.add = add;
// module.exports.subs = subs;
// module.exports.name = name;

// module.exports.add1 = add;
// module.exports.subs2 = subs;
// module.exports.name3 = name;

