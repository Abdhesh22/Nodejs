// const oper = require('./oper');

// console.log(add(5,5));
// console.log(oper);
// // console.log(add);
// console.log(oper.add(5,5));
// console.log(oper.subs(5,5));
// console.log(oper.name);

const {add,subs,name} = require('./oper');
console.log(add(5,5));
console.log(subs(5,5));
console.log(name);