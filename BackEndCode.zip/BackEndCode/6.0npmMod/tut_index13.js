const validator = require("validator");
// npm i validator
const res = validator.isEmail("abdkumar03@gmail.com");
console.log(res);