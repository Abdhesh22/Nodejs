// (function (){
//     const name = "abdhesh";
//     console.log(name);
// }) //this is module wrapper function

const name = "abdhesh";
console.log(name);